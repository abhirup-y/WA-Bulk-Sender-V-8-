// server.js — Express API + static UI
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { parse } = require('csv-parse/sync');
const { db, log } = require('./db');
const wa = require('./wa');
const scheduler = require('./scheduler');

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({ dest: UPLOAD_DIR });

// ---------- WhatsApp connection ----------
app.get('/api/wa/status', (req, res) => {
  res.json(wa.getStatus());
});

app.post('/api/wa/connect', async (req, res) => {
  try {
    await wa.startSocket();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/wa/logout', async (req, res) => {
  await wa.logout();
  res.json({ ok: true });
});

// ---------- Groups ----------
app.post('/api/groups/sync', async (req, res) => {
  try {
    const count = await wa.fetchGroups();
    res.json({ ok: true, count });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/groups', (req, res) => {
  const rows = db.prepare('SELECT * FROM groups ORDER BY name').all();
  res.json(rows);
});

// Download all joined groups as CSV (compatible with the campaign CSV upload format).
app.get('/api/groups/export.csv', (req, res) => {
  const rows = db.prepare('SELECT * FROM groups ORDER BY name').all();
  const esc = (s) => {
    const v = String(s == null ? '' : s);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  };
  const header = 'group_name,jid,admin_only,last_synced\n';
  const body = rows.map(g =>
    [g.name, g.jid, g.is_admin_only ? 'yes' : 'no', g.last_synced ? new Date(g.last_synced).toISOString() : '']
      .map(esc).join(',')
  ).join('\n');
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="whatsapp-groups-${stamp}.csv"`);
  res.send(header + body + '\n');
});

// ---------- Batches (saved group selections) ----------
app.get('/api/batches', (req, res) => {
  const rows = db.prepare('SELECT * FROM batches ORDER BY id DESC').all();
  res.json(rows);
});

app.get('/api/batches/:id', (req, res) => {
  const batch = db.prepare('SELECT * FROM batches WHERE id=?').get(req.params.id);
  if (!batch) return res.status(404).json({ error: 'Not found' });
  const groups = db.prepare('SELECT * FROM batch_groups WHERE batch_id=?').all(req.params.id);
  res.json({ batch, groups });
});

app.post('/api/batches', (req, res) => {
  try {
    const { name, group_jids } = req.body || {};
    if (!name || !Array.isArray(group_jids) || !group_jids.length) {
      return res.status(400).json({ error: 'name and group_jids[] required' });
    }
    const allGroups = db.prepare('SELECT * FROM groups').all();
    const byJid = new Map(allGroups.map(g => [g.jid, g]));
    const picks = group_jids.map(j => byJid.get(j)).filter(Boolean);
    if (!picks.length) return res.status(400).json({ error: 'No matching groups (try Sync first)' });

    const info = db.prepare('INSERT INTO batches (name, created_at) VALUES (?,?)').run(name, Date.now());
    const batchId = info.lastInsertRowid;
    const insertBg = db.prepare('INSERT INTO batch_groups (batch_id, group_jid, group_name) VALUES (?,?,?)');
    const tx = db.transaction((items) => { for (const it of items) insertBg.run(batchId, it.jid, it.name); });
    tx(picks);
    log('info', `Batch "${name}" saved with ${picks.length} groups`);
    res.json({ ok: true, batch_id: batchId, count: picks.length });
  } catch (e) {
    log('error', 'Save batch failed: ' + e.message);
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/batches/:id', (req, res) => {
  try {
    const { name, group_jids } = req.body || {};
    const batch = db.prepare('SELECT * FROM batches WHERE id=?').get(req.params.id);
    if (!batch) return res.status(404).json({ error: 'Not found' });
    if (name) db.prepare("UPDATE batches SET name=? WHERE id=?").run(name, req.params.id);
    if (Array.isArray(group_jids)) {
      const allGroups = db.prepare('SELECT * FROM groups').all();
      const byJid = new Map(allGroups.map(g => [g.jid, g]));
      const picks = group_jids.map(j => byJid.get(j)).filter(Boolean);
      db.prepare('DELETE FROM batch_groups WHERE batch_id=?').run(req.params.id);
      const insertBg = db.prepare('INSERT INTO batch_groups (batch_id, group_jid, group_name) VALUES (?,?,?)');
      const tx = db.transaction((items) => { for (const it of items) insertBg.run(req.params.id, it.jid, it.name); });
      tx(picks);
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/batches/:id', (req, res) => {
  db.prepare('DELETE FROM batches WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Download a batch as CSV
app.get('/api/batches/:id/export.csv', (req, res) => {
  const batch = db.prepare('SELECT * FROM batches WHERE id=?').get(req.params.id);
  if (!batch) return res.status(404).send('Batch not found');
  const groups = db.prepare('SELECT * FROM batch_groups WHERE batch_id=?').all(req.params.id);
  const esc = (s) => {
    const v = String(s == null ? '' : s);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  };
  const safe = String(batch.name || 'batch').replace(/[^A-Za-z0-9_-]+/g, '_');
  const body = 'group_name,jid\n' + groups.map(g => [g.group_name, g.group_jid].map(esc).join(',')).join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="batch-${safe}.csv"`);
  res.send(body + '\n');
});

// ---------- Campaigns ----------
app.post('/api/campaigns', upload.fields([
  { name: 'csv', maxCount: 1 },
  { name: 'image', maxCount: 1 },
  { name: 'video', maxCount: 1 },
  { name: 'media', maxCount: 1 },
]), (req, res) => {
  try {
    const { name, message, delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour, batch_id } = req.body;
    if (!name || !message) return res.status(400).json({ error: 'name and message required' });

    const allGroups = db.prepare('SELECT * FROM groups').all();
    const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
    const groupMap = new Map(allGroups.map(g => [norm(g.name), g]));
    const byJid = new Map(allGroups.map(g => [g.jid, g]));

    const matched = [];
    const unmatched = [];
    const csvFile = req.files?.csv?.[0];

    if (batch_id) {
      // Source: saved batch
      const batch = db.prepare('SELECT * FROM batches WHERE id=?').get(batch_id);
      if (!batch) return res.status(400).json({ error: 'Batch not found' });
      const bgs = db.prepare('SELECT * FROM batch_groups WHERE batch_id=?').all(batch_id);
      if (!bgs.length) return res.status(400).json({ error: 'Batch has no groups' });
      for (const bg of bgs) {
        // Re-verify the group is still joined (jid first, fall back to name)
        const g = byJid.get(bg.group_jid) || groupMap.get(norm(bg.group_name));
        if (g) matched.push({ jid: g.jid, name: g.name });
        else unmatched.push(bg.group_name);
      }
    } else if (csvFile) {
      // Source: uploaded CSV
      const csvText = fs.readFileSync(csvFile.path, 'utf8');
      const records = parse(csvText, { columns: true, skip_empty_lines: true, trim: true });
      if (!records.length) return res.status(400).json({ error: 'CSV is empty' });

      const firstRow = records[0];
      const cols = Object.keys(firstRow);
      let nameCol = cols.find(c => /group.?name|name|group/i.test(c)) || cols[0];

      for (const r of records) {
        const gname = r[nameCol];
        const g = groupMap.get(norm(gname));
        if (g) matched.push({ jid: g.jid, name: g.name });
        else unmatched.push(gname);
      }
    } else {
      return res.status(400).json({ error: 'Provide either a CSV file or a batch_id' });
    }

    if (!matched.length) {
      return res.status(400).json({ error: 'No group names matched your joined groups. Click "Sync My Groups" first.', unmatched });
    }

    // Media: any of `media`, `image`, or `video` fields work.
    // We keep the column name `image_path` for backward compatibility but
    // also store `media_type` ('image' | 'video') so the scheduler picks the
    // right Baileys envelope.
    const mediaFile = req.files?.media?.[0] || req.files?.video?.[0] || req.files?.image?.[0];
    const mediaPath = mediaFile?.path || null;
    let mediaType = null;
    if (mediaFile) {
      const mt = (mediaFile.mimetype || '').toLowerCase();
      const ext = path.extname(mediaFile.originalname || mediaFile.path || '').toLowerCase();
      if (mt.startsWith('video/') || ['.mp4','.mov','.m4v','.3gp','.webm','.mkv'].includes(ext)) mediaType = 'video';
      else mediaType = 'image';
    }

    const info = db.prepare(`
      INSERT INTO campaigns (name, message, image_path, media_type, delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour, created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)
    `).run(
      name,
      message,
      mediaPath,
      mediaType,
      parseInt(delay_min) || 60,
      parseInt(delay_max) || 120,
      parseInt(per_day_cap) || 200,
      parseInt(day_start_hour) || 10,
      parseInt(day_end_hour) || 21,
      Date.now()
    );
    const campaignId = info.lastInsertRowid;

    const insertTarget = db.prepare(`INSERT INTO campaign_targets (campaign_id, group_jid, group_name) VALUES (?,?,?)`);
    const tx = db.transaction((items) => { for (const it of items) insertTarget.run(campaignId, it.jid, it.name); });
    tx(matched);

    // Cleanup CSV file
    if (csvFile) { try { fs.unlinkSync(csvFile.path); } catch {} }

    res.json({ ok: true, campaign_id: campaignId, matched: matched.length, unmatched });
  } catch (e) {
    log('error', 'Create campaign failed: ' + e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/campaigns', (req, res) => {
  const rows = db.prepare(`
    SELECT c.*,
      (SELECT COUNT(*) FROM campaign_targets WHERE campaign_id=c.id) as total,
      (SELECT COUNT(*) FROM campaign_targets WHERE campaign_id=c.id AND status='sent') as sent,
      (SELECT COUNT(*) FROM campaign_targets WHERE campaign_id=c.id AND status='failed') as failed,
      (SELECT COUNT(*) FROM campaign_targets WHERE campaign_id=c.id AND status='skipped') as skipped,
      (SELECT COUNT(*) FROM campaign_targets WHERE campaign_id=c.id AND status='pending') as pending
    FROM campaigns c ORDER BY id DESC
  `).all();
  res.json(rows);
});

app.get('/api/campaigns/:id', (req, res) => {
  const camp = db.prepare('SELECT * FROM campaigns WHERE id=?').get(req.params.id);
  if (!camp) return res.status(404).json({ error: 'Not found' });
  const targets = db.prepare('SELECT * FROM campaign_targets WHERE campaign_id=? ORDER BY id').all(req.params.id);
  const stats = {
    total: targets.length,
    sent: targets.filter(t => t.status === 'sent').length,
    failed: targets.filter(t => t.status === 'failed').length,
    skipped: targets.filter(t => t.status === 'skipped').length,
    pending: targets.filter(t => t.status === 'pending').length,
  };
  res.json({ campaign: camp, targets, stats });
});

app.post('/api/campaigns/:id/start', (req, res) => {
  try {
    scheduler.startCampaign(parseInt(req.params.id));
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/campaigns/:id/pause', (req, res) => {
  const r = scheduler.pauseCampaign(parseInt(req.params.id));
  if (!r.ok) return res.status(400).json({ error: r.error });
  res.json({ ok: true });
});

app.post('/api/campaigns/:id/stop', (req, res) => {
  const r = scheduler.stopCampaign(parseInt(req.params.id));
  if (!r.ok) return res.status(400).json({ error: r.error });
  res.json({ ok: true, forced: !!r.forced });
});

// Re-queue skipped + failed targets so the campaign can retry them.
// Useful after fixing the not_member / metadata_error bug, or after WA reconnect.
app.post('/api/campaigns/:id/retry', (req, res) => {
  try {
    if (scheduler.getRunningId() == req.params.id) {
      return res.status(400).json({ error: 'Campaign is running — stop it first' });
    }
    const result = scheduler.retryCampaign(parseInt(req.params.id));
    res.json({ ok: true, requeued: result.requeued });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/campaigns/:id', (req, res) => {
  if (scheduler.getRunningId() == req.params.id) return res.status(400).json({ error: 'Stop campaign first' });
  db.prepare('DELETE FROM campaign_targets WHERE campaign_id=?').run(req.params.id);
  db.prepare('DELETE FROM campaigns WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Logs ----------
app.get('/api/logs', (req, res) => {
  const rows = db.prepare('SELECT * FROM logs ORDER BY id DESC LIMIT 200').all();
  res.json(rows);
});

// ---------- Start ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n============================================`);
  console.log(`  WA Bulk Sender running`);
  console.log(`  Open in browser: http://localhost:${PORT}`);
  console.log(`============================================\n`);
});

// Auto-start WhatsApp socket on launch (uses saved session if present)
wa.startSocket().catch((e) => log('error', 'startSocket on boot failed: ' + e.message));
