// wa.js — WhatsApp connection via Baileys
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const path = require('path');
const fs = require('fs');
const qrcode = require('qrcode');
const { db, log } = require('./db');

const SESSION_DIR = path.join(__dirname, 'sessions');
if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

let sock = null;
let currentQR = null;
let connectionState = 'disconnected'; // disconnected | connecting | qr | connected

function getStatus() {
  return {
    state: connectionState,
    qr: currentQR,
    user: sock?.user || null,
  };
}

async function startSocket() {
  if (sock && connectionState === 'connected') return sock;

  connectionState = 'connecting';
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    // Suppress Baileys' noisy decrypt + reconnect errors ("No session found",
    // "Timed Out in init queries" etc). These are inbound-traffic / sync
    // hiccups and do not affect outbound sends. Set to 'warn' if debugging.
    logger: pino({ level: 'silent' }),
    browser: ['WA Bulk Sender', 'Chrome', '1.0.0'],
    syncFullHistory: false,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      try {
        currentQR = await qrcode.toDataURL(qr);
        connectionState = 'qr';
        log('info', 'QR code generated — scan from WhatsApp app');
      } catch (e) {
        log('error', 'QR encode failed: ' + e.message);
      }
    }
    if (connection === 'open') {
      currentQR = null;
      connectionState = 'connected';
      log('info', `Connected as ${sock.user?.id || 'unknown'}`);
    }
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      log('warn', `Disconnected. code=${code} loggedOut=${loggedOut}`);
      connectionState = 'disconnected';
      currentQR = null;
      if (!loggedOut) {
        setTimeout(() => startSocket().catch(e => log('error', 'reconnect failed: ' + e.message)), 3000);
      } else {
        // Wipe session so next start shows QR again
        try {
          for (const f of fs.readdirSync(SESSION_DIR)) fs.unlinkSync(path.join(SESSION_DIR, f));
        } catch {}
      }
    }
  });

  return sock;
}

async function logout() {
  try {
    if (sock) await sock.logout();
  } catch {}
  sock = null;
  connectionState = 'disconnected';
  currentQR = null;
  try {
    for (const f of fs.readdirSync(SESSION_DIR)) fs.unlinkSync(path.join(SESSION_DIR, f));
  } catch {}
}

async function fetchGroups() {
  if (!sock || connectionState !== 'connected') throw new Error('Not connected');
  const data = await sock.groupFetchAllParticipating();
  const upsert = db.prepare(
    `INSERT INTO groups (jid, name, is_admin_only, i_am_member, last_synced)
     VALUES (?,?,?,?,?)
     ON CONFLICT(jid) DO UPDATE SET name=excluded.name, is_admin_only=excluded.is_admin_only, i_am_member=1, last_synced=excluded.last_synced`
  );
  const mine = myParticipantIds();
  let count = 0;
  for (const jid of Object.keys(data)) {
    const g = data[jid];
    let adminOnly = 0;
    if (g.announce) {
      // announce=true means only admins can send. Check if I am admin.
      const meParticipant = g.participants?.find(p => {
        const u = jidUser(p.id);
        if (mine.has(u)) return true;
        if (p.jid && mine.has(jidUser(p.jid))) return true;
        return false;
      });
      const isAdmin = meParticipant && (meParticipant.admin === 'admin' || meParticipant.admin === 'superadmin');
      adminOnly = isAdmin ? 0 : 1;
    }
    upsert.run(jid, g.subject || '', adminOnly, 1, Date.now());
    count++;
  }
  log('info', `Fetched ${count} groups`);
  return count;
}

function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`Timeout after ${ms}ms (${label})`)), ms);
    promise.then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); }
    );
  });
}

// Extract just the numeric phone (or lid) part from a Baileys JID:
//   919999999999:23@s.whatsapp.net  -> 919999999999
//   919999999999@s.whatsapp.net     -> 919999999999
//   12345678901234@lid              -> 12345678901234
function jidUser(jid) {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
}

// Build the set of identifiers that should match "me" in a participant list.
// Baileys may give us either the phone-JID id or the @lid id depending on
// account type and version, so we check several forms.
function myParticipantIds() {
  const ids = new Set();
  const u = sock?.user;
  if (!u) return ids;
  if (u.id) ids.add(jidUser(u.id));
  if (u.lid) ids.add(jidUser(u.lid));
  // Sometimes user.id is already a plain phone number
  return ids;
}

async function checkCanSend(jid) {
  // Fresh metadata fetch — verify the group permits sends.
  // IMPORTANT: if metadata fetch fails (timeout / socket flap / WA Web throttle),
  // we do NOT pre-skip the group. We let sendMessage itself decide — Baileys
  // will reject with a clear error if we're not a member.
  let meta;
  try {
    meta = await withTimeout(sock.groupMetadata(jid), 15000, 'groupMetadata');
  } catch (e) {
    log('warn', `groupMetadata failed for ${jid} (${e.message}) — attempting send anyway`);
    return { ok: true, skippedPreflight: true };
  }

  const mine = myParticipantIds();
  const myParticipant = meta.participants?.find(p => {
    const u = jidUser(p.id);
    if (mine.has(u)) return true;
    // Some Baileys versions also expose p.jid or p.phoneNumber
    if (p.jid && mine.has(jidUser(p.jid))) return true;
    return false;
  });

  if (!myParticipant) {
    // If we couldn't identify ourselves at all (mine is empty), be lenient —
    // don't skip the group, let send try and report a real error.
    if (mine.size === 0) {
      log('warn', `Could not determine self-JID; skipping pre-flight membership check for ${jid}`);
      return { ok: true, skippedPreflight: true };
    }
    return { ok: false, reason: 'not_member' };
  }
  if (meta.announce) {
    const isAdmin = myParticipant.admin === 'admin' || myParticipant.admin === 'superadmin';
    if (!isAdmin) return { ok: false, reason: 'admin_only' };
  }
  return { ok: true };
}

// Quick media-type guess from extension. We store media_type in DB when
// the campaign is created, but fall back to extension sniffing here so old
// rows (image_path only) still work.
function guessMediaType(p) {
  if (!p) return null;
  const ext = path.extname(p).toLowerCase();
  if (['.mp4', '.mov', '.m4v', '.3gp', '.webm', '.mkv'].includes(ext)) return 'video';
  if (['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp'].includes(ext)) return 'image';
  return null;
}

function mimeForVideo(p) {
  const ext = path.extname(p).toLowerCase();
  if (ext === '.mov') return 'video/quicktime';
  if (ext === '.webm') return 'video/webm';
  if (ext === '.mkv') return 'video/x-matroska';
  if (ext === '.3gp') return 'video/3gpp';
  return 'video/mp4';
}

async function sendToGroup(jid, message, mediaPath, mediaType) {
  if (!sock || connectionState !== 'connected') throw new Error('Not connected');

  // Pre-flight check — saves us from getting stuck
  const check = await checkCanSend(jid);
  if (!check.ok) {
    const err = new Error(check.reason);
    err.code = check.reason;
    throw err;
  }

  let sendPromise;
  if (mediaPath && fs.existsSync(mediaPath)) {
    const kind = mediaType || guessMediaType(mediaPath) || 'image';
    const buf = fs.readFileSync(mediaPath);
    if (kind === 'video') {
      sendPromise = sock.sendMessage(jid, {
        video: buf,
        caption: message || '',
        mimetype: mimeForVideo(mediaPath),
      });
    } else {
      sendPromise = sock.sendMessage(jid, { image: buf, caption: message || '' });
    }
  } else {
    sendPromise = sock.sendMessage(jid, { text: message });
  }

  // Hard timeout — videos take longer to upload, so give them more room.
  const isVideoSend = mediaPath && (mediaType === 'video' || guessMediaType(mediaPath) === 'video');
  const timeoutMs = isVideoSend ? 120000 : 30000;
  await withTimeout(sendPromise, timeoutMs, 'sendMessage');
}

module.exports = { startSocket, logout, getStatus, fetchGroups, sendToGroup, guessMediaType };
