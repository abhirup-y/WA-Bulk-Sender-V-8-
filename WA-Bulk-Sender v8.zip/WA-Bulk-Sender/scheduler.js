// scheduler.js — campaign execution engine
const { db, log } = require('./db');
const wa = require('./wa');

let runningCampaignId = null;
let stopRequested = false;
let pauseRequested = false;
let currentTimer = null;
let currentSleepReject = null; // lets stop/pause break out of an in-flight sleep

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sleep(ms) {
  return new Promise((res, rej) => {
    currentSleepReject = () => {
      currentSleepReject = null;
      // Resolve (not reject) so the loop continues to its own stop/pause check.
      res();
    };
    currentTimer = setTimeout(() => {
      currentTimer = null;
      currentSleepReject = null;
      res();
    }, ms);
  });
}

function interruptSleep() {
  if (currentTimer) {
    clearTimeout(currentTimer);
    currentTimer = null;
  }
  if (currentSleepReject) {
    const fn = currentSleepReject;
    currentSleepReject = null;
    try { fn(); } catch {}
  }
}

function inDayWindow(camp) {
  const h = new Date().getHours();
  return h >= camp.day_start_hour && h < camp.day_end_hour;
}

function sentToday(campaignId) {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const row = db
    .prepare(`SELECT COUNT(*) as c FROM campaign_targets WHERE campaign_id=? AND status='sent' AND sent_at >= ?`)
    .get(campaignId, startOfDay.getTime());
  return row?.c || 0;
}

async function runCampaign(campaignId) {
  if (runningCampaignId) throw new Error('Another campaign is already running');
  runningCampaignId = campaignId;
  stopRequested = false;
  pauseRequested = false;

  const camp = db.prepare('SELECT * FROM campaigns WHERE id=?').get(campaignId);
  if (!camp) {
    runningCampaignId = null;
    throw new Error('Campaign not found');
  }

  db.prepare(`UPDATE campaigns SET status='running', started_at=COALESCE(started_at, ?) WHERE id=?`).run(Date.now(), campaignId);
  log('info', `Campaign ${campaignId} started`);

  let consecutiveFails = 0;

  while (true) {
    if (stopRequested) {
      db.prepare(`UPDATE campaigns SET status='stopped', finished_at=? WHERE id=?`).run(Date.now(), campaignId);
      log('info', `Campaign ${campaignId} stopped`);
      break;
    }
    if (pauseRequested) {
      db.prepare(`UPDATE campaigns SET status='paused' WHERE id=?`).run(campaignId);
      log('info', `Campaign ${campaignId} paused`);
      break;
    }

    // Check day window
    if (!inDayWindow(camp)) {
      log('info', `Outside day window (${camp.day_start_hour}-${camp.day_end_hour}). Waiting 10 min...`);
      await sleep(10 * 60 * 1000);
      continue;
    }

    // Check per-day cap
    const todayCount = sentToday(campaignId);
    if (todayCount >= camp.per_day_cap) {
      log('info', `Per-day cap (${camp.per_day_cap}) reached. Sleeping 30 min and rechecking date...`);
      await sleep(30 * 60 * 1000);
      continue;
    }

    // Pick next pending target
    const target = db
      .prepare(`SELECT * FROM campaign_targets WHERE campaign_id=? AND status='pending' ORDER BY id LIMIT 1`)
      .get(campaignId);
    if (!target) {
      db.prepare(`UPDATE campaigns SET status='done', finished_at=? WHERE id=?`).run(Date.now(), campaignId);
      log('info', `Campaign ${campaignId} finished — no more pending targets`);
      break;
    }

    // Skip admin-only groups (best-effort lookup)
    const grp = db.prepare('SELECT * FROM groups WHERE jid=?').get(target.group_jid);
    if (grp && grp.is_admin_only) {
      const res = db.prepare(`UPDATE campaign_targets SET status='skipped', error=?, sent_at=? WHERE id=?`).run('admin_only', Date.now(), target.id);
      log('warn', `Skipped admin-only group: ${target.group_name || target.group_jid}`);
      if (!res.changes) {
        log('error', `Target id=${target.id} could not be updated. Bailing out to avoid infinite loop.`);
        db.prepare(`UPDATE campaigns SET status='paused' WHERE id=?`).run(campaignId);
        break;
      }
      await sleep(500);
      continue;
    }

    try {
      await wa.sendToGroup(target.group_jid, camp.message, camp.image_path, camp.media_type);
      // If user hit Stop mid-send, do not record the send as a campaign sent
      // is fine to record (message did go out) but bail before sleeping.
      db.prepare(`UPDATE campaign_targets SET status='sent', sent_at=? WHERE id=?`).run(Date.now(), target.id);
      consecutiveFails = 0;
      log('info', `Sent → ${target.group_name || target.group_jid}`);
    } catch (e) {
      const errMsg = String(e?.message || e).slice(0, 500);
      const code = e?.code || '';
      // "Soft" errors that should be SKIPPED, not counted as failures
      // Soft-skip categories: clearly the group's fault, not WhatsApp throttling us.
      // Transient "metadata_error" / timeouts are NOT soft anymore — we now retry
      // pre-flight and let the actual send decide.
      const isSoft = code === 'admin_only' || code === 'not_member' || /admin.?only|not.?member/i.test(errMsg);
      if (isSoft) {
        db.prepare(`UPDATE campaign_targets SET status='skipped', error=?, sent_at=? WHERE id=?`).run(code || errMsg, Date.now(), target.id);
        // Mark group as admin-only in DB so future campaigns auto-skip
        if (code === 'admin_only') {
          try {
            const upd = db.prepare(`INSERT INTO groups (jid, name, is_admin_only, i_am_member, last_synced) VALUES (?,?,?,?,?)`);
            const g = db.prepare('SELECT * FROM groups WHERE jid=?').get(target.group_jid);
            upd.run(target.group_jid, g?.name || target.group_name, 1, 1, Date.now());
          } catch {}
        }
        log('warn', `Skipped → ${target.group_name || target.group_jid} (${code || 'soft'})`);
        // Soft skip — do NOT increment consecutiveFails, do NOT use the long delay
        await sleep(2000);
        continue;
      }
      db.prepare(`UPDATE campaign_targets SET status='failed', error=?, sent_at=? WHERE id=?`).run(errMsg, Date.now(), target.id);
      consecutiveFails++;
      log('error', `Failed → ${target.group_name || target.group_jid}: ${errMsg}`);
      if (consecutiveFails >= 5) {
        log('error', `5 consecutive HARD failures — auto-pausing campaign for safety`);
        db.prepare(`UPDATE campaigns SET status='paused' WHERE id=?`).run(campaignId);
        break;
      }
    }

    // Random delay (interruptible)
    if (stopRequested || pauseRequested) continue; // re-check immediately
    const delaySec = rand(camp.delay_min, camp.delay_max);
    log('info', `Sleeping ${delaySec}s before next send...`);
    await sleep(delaySec * 1000);
  }

  runningCampaignId = null;
  stopRequested = false;
  pauseRequested = false;
}

function startCampaign(campaignId) {
  // Fire and forget
  runCampaign(campaignId).catch((e) => {
    log('error', `Campaign run crashed: ${e.message}`);
    db.prepare(`UPDATE campaigns SET status='paused' WHERE id=?`).run(campaignId);
    runningCampaignId = null;
  });
}

function pauseCampaign(campaignId) {
  // Only act if a campaign is actually running (and matches, if id given)
  if (!runningCampaignId) return { ok: false, error: 'No campaign is running' };
  if (campaignId != null && runningCampaignId != campaignId) {
    return { ok: false, error: `Different campaign is running (#${runningCampaignId})` };
  }
  pauseRequested = true;
  interruptSleep();
  return { ok: true };
}

function stopCampaign(campaignId) {
  if (!runningCampaignId) {
    // Allow a forced status update for stuck campaigns (status='running' but no in-memory runner)
    if (campaignId != null) {
      const c = db.prepare('SELECT * FROM campaigns WHERE id=?').get(campaignId);
      if (c && c.status === 'running') {
        db.prepare(`UPDATE campaigns SET status='stopped', finished_at=? WHERE id=?`).run(Date.now(), campaignId);
        log('warn', `Campaign ${campaignId} was marked running but no runner found — forced to stopped`);
        return { ok: true, forced: true };
      }
    }
    return { ok: false, error: 'No campaign is running' };
  }
  if (campaignId != null && runningCampaignId != campaignId) {
    return { ok: false, error: `Different campaign is running (#${runningCampaignId})` };
  }
  stopRequested = true;
  interruptSleep();
  return { ok: true };
}

function getRunningId() {
  return runningCampaignId;
}

function retryCampaign(campaignId) {
  // Flip skipped + failed back to pending; reset campaign status so user can hit Start again.
  const targets = db.prepare('SELECT * FROM campaign_targets WHERE campaign_id=? ORDER BY id').all(campaignId);
  let requeued = 0;
  for (const t of targets) {
    if (t.status === 'skipped' || t.status === 'failed') {
      // Use the existing UPDATE shapes the JSON-store shim knows about.
      // 'sent' status path also handles flipping back when we pass status text —
      // but we want plain 'pending'. The store is JSON, so just mutate via the
      // raw store handle exposed by db.prepare for known queries below.
      requeued++;
    }
  }
  // The JSON-store shim doesn't have a generic UPDATE-to-pending, so we add one
  // here via a dedicated query the shim now understands.
  db.prepare("UPDATE campaign_targets SET status='pending', error=NULL, sent_at=NULL WHERE campaign_id=? AND status IN ('skipped','failed')").run(campaignId);
  // Reset campaign to 'created' so the UI shows Start as a fresh action.
  db.prepare("UPDATE campaigns SET status='created', finished_at=NULL WHERE id=?").run(campaignId);
  log('info', `Campaign ${campaignId} retry: requeued ${requeued} target(s)`);
  return { requeued };
}

module.exports = { startCampaign, pauseCampaign, stopCampaign, getRunningId, retryCampaign };
