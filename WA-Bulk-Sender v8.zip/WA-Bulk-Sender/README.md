# WA Bulk Sender 📨

WhatsApp groups mein bulk message bhejne ka local tool — text + image, random delays, batch scheduling, resume on crash. Sab kuch tere laptop pe chalta hai. No data leaves your machine.

---

## ⚠️ READ THIS FIRST

- **Use a burner WhatsApp number.** Personal number kabhi mat use karna.
- WhatsApp ko bulk messaging pasand nahi. Tool best-effort safety deta hai (delays, batches, caps) but **ban risk hamesha rehta hai**.
- Aggressive use = number ban. Conservative defaults se start kar (60-120s delay, 200/day cap).
- Tool sirf legit information sharing ke liye banaya gaya hai. Spam/illegal use mat karna — responsibility teri hai.

---

## 1. One-time setup (sirf pehli baar, har device pe)

### Step 1: Node.js install kar

Agar Node.js nahi hai:
1. Open: https://nodejs.org/en/download
2. **Windows Installer (.msi) LTS version** download kar
3. Install kar (default settings — Next, Next, Finish)
4. Verify: `Win + R` → type `cmd` → enter →
   ```
   node --version
   ```
   Agar `v20.x.x` jaisa kuch dikha to ✅ ready.

### Step 2: Folder ko sahi jagah rakh

- Zip extract karne ke baad folder ka path simple rakho — e.g. **Desktop pe `WA-Bulk-Sender`** (no nested folders like `WA-Bulk-Sender\WA-Bulk-Sender`).
- Folder ko `Downloads`, `Desktop`, ya kahin bhi rakh sakta hai — bas path me OneDrive sync wali jagah avoid kar (slow ho jata hai).

### Step 3: `INSTALL.bat` double-click kar

- Folder me **`INSTALL.bat`** double-click kar.
- Ye automatically:
  - Node.js check karega
  - Old/incomplete `node_modules` clean karega (zip transfer ke baad common issue)
  - Fresh dependencies install karega (~2-3 min, internet chahiye)
- "Setup done!" dikhe to band kar de — sirf ek baar karna hai.

> ⚠️ Zip transfer ke baad agar `Cannot find module 'express'` jaisa error aaye, to wo zip ka `node_modules` corrupt tha. **`INSTALL.bat` chala** — wo old `node_modules` delete karke fresh install kar dega.

---

## 2. Tool start karna (har baar)

Folder me **`START.bat`** double-click kar. Bas.

Ya CMD se:
```
cd "%USERPROFILE%\Desktop\WA-Bulk-Sender"
npm start
```

Tu dekhega:
```
============================================
  WA Bulk Sender running
  Open in browser: http://localhost:3000
============================================
```

Browser apne aap khulega (~4s baad). Ya manually khol: **http://localhost:3000**

> ⚠️ CMD window **band mat karna** jab tak campaign chal raha hai. Band karne ke liye `Ctrl + C` press kar.

---

## 3. Tool use kaise karna hai

### A. WhatsApp connect kar (sirf pehli baar)

1. Page khulte hi top-right pe **"🟡 Waiting for QR scan"** dikhega
2. Phone mein burner number wale WhatsApp ko khol:
   - **WhatsApp → Settings → Linked Devices → Link a Device**
   - Browser mein dikhne wala QR scan kar
3. Pill 🟢 **Connected** ho jayega — saved session bann gaya, agli baar QR nahi karna hoga

### B. Apne groups sync kar

1. **"🔄 Sync My Groups"** button click kar
2. WhatsApp se sare groups (jisme tu member hai) database mein aa jayenge
3. Admin-only groups automatically detect ho jayenge — campaign mein skip honge
4. Sync ke baad **groups ki table** dikhega — checkboxes ke saath. Filter box se search kar sakta hai.

#### 🆕 Groups CSV download karna (device pe save)

Sync ke baad **"⬇ Download all groups (CSV)"** button dabao — tere browser ka default download folder mein `whatsapp-groups-YYYY-MM-DD.csv` save ho jayega. Columns: `group_name, jid, admin_only, last_synced`. Yahi CSV directly campaign mein bhi upload kar sakta hai (ya Excel mein edit karke filter kar).

### C. Batch banao (recommended — ek baar select, baar baar use)

Batch = saved group selection. Ek baar groups chuno, naam do, save karo — future campaigns mein same groups auto-pick ho jayenge. CSV banane ki zarurat nahi.

1. Groups table mein checkbox tick karo (ya "Select all (filtered)" se ek shot mein)
2. Niche **"Batch name"** mein naam likho (e.g. *Monthly Newsletter*, *Branch Heads*, *NCR Groups*)
3. **"💾 Save selected as Batch"** click karo
4. **"📦 Saved Batches"** section mein dikhega — yahin se delete, view, ya CSV download kar sakta hai

> Pro tip: alag use-cases ke alag batches banao (e.g. *NCR-Only*, *All Members*, *Branch Heads*). Campaign create karte waqt dropdown se pick karo.

### D. (Alternative) CSV banao

Agar batch nahi banana — ya bahar se list aayi hai — CSV mein bas ek column chahiye: **`group_name`** — exactly waisa hi naam jaisa WhatsApp pe group ka hai.

Example CSV (`groups.csv`):
```csv
group_name
ICAI Members Connect
CA Yadav Network
Civil Engineers India
Branch Updates 2026
```

> Tip: Excel mein bana, fir **Save As → CSV (Comma delimited) (.csv)** kar. Ya "Download all groups (CSV)" se base file le aur usme se rows hata.

### E. Campaign create kar

1. **"Create Campaign"** section bhar:
   - **Campaign name** — apna reference (e.g. "June Info Drop")
   - **Message text** — jo bhejna hai (image use kar raha hai to ye caption banega)
   - **Send to which groups?** — dropdown se chuno:
     - **📦 Use a saved batch** (default) — niche batch dropdown se pick karo
     - **📄 Upload a CSV** — file upload
   - **Image** (optional) — upload kar
   - **Delay min/max (sec)** — random gap between sends. Default **60-120s** safe hai. Aggressive nahi karna.
   - **Per-day cap** — ek din mein max kitne. Default **200**. Naya number hai to **100** se start kar.
   - **Day start/end hour** — kis time window mein bhejna hai (e.g. 10 to 21 = 10 AM to 9 PM). Raat ko avoid hi karo.
2. **"➕ Create Campaign"** click kar
3. Tujhe dikhega: kitne groups match hue, kitne unmatched (typo / left group)

### F. Campaign start kar

1. **"Campaigns"** section mein scroll
2. **▶ Start/Resume** click kar
3. Live progress, sent/failed count, aur "Live Logs" mein har action dikhega
4. Anytime **⏸ Pause** ya **⏹ Stop** kar sakta hai

**Resume:** Pause/stop ke baad ya laptop restart ke baad bhi, ▶ Start dabane se pending wale group se shuru hoga. Sent hue dobara nahi jayenge.

---

## 4. Multi-day batching

Ye tool **automatic batching** karta hai:

- Per-day cap reach ho gaya → auto-pause, agle din auto-resume (jab tu start dabayega ya laptop ON hoga)
- Day window ke bahar → wait, andar aane par resume
- 5 consecutive failures → safety pause (manually check kar)

**Tera 700 groups 3-day plan:**
- Per-day cap **250** set kar → 3 din mein cover ho jayega
- Ya **150** set kar → 5 din safer

---

## 5. Safety tips (ban se bachne ke liye)

✅ **Burner number warm up** kar pehle — 1-2 hafte normal use (5-10 contacts, casual chat, status post)
✅ Delay **60-120s minimum** rakh
✅ Per-day cap **200 se kam** rakh
✅ Image hash same hai sab jagah — flag risk. Possible ho to har 50 groups ke baad image thoda crop/change kar
✅ Day window **10 AM - 9 PM**, raat avoid
✅ **Pehla red flag** dikhe (multiple consecutive failures, "message not delivered") → ruk
❌ Same exact text 500+ groups mein → ban guaranteed
❌ Bina warm-up naya number → ban first day
❌ 10-20 sec delay → spam pattern, ban

---

## 6. Troubleshooting

**Q: `npm install` mein error aa rha hai?**
A: Antivirus ya corporate proxy block kar raha hoga. CMD admin se chala, ya internet check kar.

**Q: QR scan nahi ho rha?**
A: Page refresh kar. Ya CMD mein `Ctrl+C` → `npm start` se restart.

**Q: "Not connected" error?**
A: Top pill check kar. 🔴 hai to QR scan kar dobara. WhatsApp Web par koi aur device link nahi hai check.

**Q: Group naam match nahi ho rha?**
A: Pehle **Sync My Groups** click kar. CSV mein group name exactly waisa hi hona chahiye jaisa WhatsApp dikha rha. Spaces/typos ka khayal rakh.

**Q: Sent ho gaya but group mein message nahi dikha?**
A: Tu member hai us group ka? Admin-only group hai jisme tu admin nahi? Tool detect karta hai but kabhi miss bhi ho sakta hai.

**Q: Saare groups “skipped (not_member)” aa rahe hain, jabki main member hoon!**
A: Ye bug pehle tha — ab fix ho gaya. Sync My Groups dobara click kar, fir campaign me 🔁 **Retry skipped/failed** button dabao (har campaign card pe naya button hai). Wo skipped + failed targets ko wapas pending kar dega, fir ▶ Start dabao. Background fix: pre-flight membership check ab Baileys ke `@lid` JID format ko bhi samajhta hai, aur metadata-fetch timeout ho jaye to skip nahi karta — actual send ko try karne deta hai.

**Q: Laptop band kar du raat ko?**
A: Haan, koi dikkat nahi. Agle din `npm start` → ▶ Start → wahin se resume.

**Q: Logs file mein chahiye?**
A: `data\store.json` mein sab data hai (groups, campaigns, logs). Notepad/VSCode se kholo.

**Q: Tool delete karna hai?**
A: Pura folder delete kar. Session bhi gaya, dobara QR scan karna hoga agli baar.

---

## 7. File structure

```
WA-Bulk-Sender/
├── server.js          # Express API
├── wa.js              # WhatsApp (Baileys) connection
├── scheduler.js       # Batch + delay engine
├── db.js              # SQLite database
├── package.json
├── public/            # Web UI (HTML/CSS/JS)
├── uploads/           # Uploaded CSVs + images
├── sessions/          # WhatsApp auth (DO NOT SHARE)
├── data/              # SQLite database
└── README.md
```

> ⚠️ `sessions/` folder mein tera WhatsApp login hai. Kisi ko share mat karna. Backup karega to encrypted location pe.

---

## 8. Quick command reference

| Action | How |
|---|---|
| **First-time setup (per device)** | Double-click `INSTALL.bat` |
| **Start tool** | Double-click `START.bat` |
| Stop tool | `Ctrl + C` in CMD window |
| Open UI | http://localhost:3000 |
| Reset login | Delete `sessions/` folder |
| Reset all data | Delete `data/` folder |
| Reinstall deps | Double-click `INSTALL.bat` again |

---

## 9. Moving the tool to another device

1. **Source code zip** (without `node_modules`) copy kar new device pe — use the **`WA-Bulk-Sender.zip`** that ships from Desktop, not your own zip of an installed copy.
2. Extract karte waqt nested folder na ban jaye — e.g. `Desktop\WA-Bulk-Sender\server.js` hona chahiye, **not** `Desktop\WA-Bulk-Sender\WA-Bulk-Sender\server.js`. Agar nested hai, inner folder ko outer pe move kar do.
3. **`INSTALL.bat`** chala (one time on this device).
4. **`START.bat`** chala.
5. WhatsApp QR scan kar dobara — sessions device-specific hain, transfer nahi hote (security feature).

---

Made for Yadav by Echo ✨
