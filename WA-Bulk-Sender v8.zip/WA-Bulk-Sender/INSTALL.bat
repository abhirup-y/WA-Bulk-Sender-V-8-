@echo off
title WA Bulk Sender - First Time Setup
cd /d "%~dp0"

echo ============================================
echo   WA Bulk Sender - First Time Setup
echo ============================================
echo.
echo This will install everything needed.
echo Internet connection required (~2-3 min).
echo.
pause

REM ---- Check Node.js ----
where node >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: Node.js is not installed on this device.
    echo.
    echo 1. Open: https://nodejs.org/en/download
    echo 2. Download Windows Installer ^(.msi^) LTS
    echo 3. Install ^(Next, Next, Finish^)
    echo 4. Run this INSTALL.bat again
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo Using Node %NODE_VER%
echo.

REM ---- Wipe any partial / corrupt node_modules from a previous zip transfer ----
if exist "node_modules" (
    echo Removing old node_modules folder...
    rmdir /s /q node_modules 2>nul
)
if exist "package-lock.json" (
    echo Removing old package-lock.json...
    del /q package-lock.json 2>nul
)

echo.
echo Installing dependencies (this takes 2-3 minutes)...
echo.
call npm install --no-fund --no-audit
if errorlevel 1 (
    echo.
    echo ============================================
    echo  ERROR: npm install failed.
    echo ============================================
    echo  Common causes:
    echo  - No internet connection
    echo  - Corporate firewall/proxy blocking npm
    echo  - Antivirus blocking node_modules writes
    echo.
    pause
    exit /b 1
)

REM Save the current Node version so START.bat can detect upgrades
echo %NODE_VER%> .node-version

echo.
echo ============================================
echo  Setup done!
echo ============================================
echo.
echo  Next step: double-click START.bat to launch.
echo.
pause
