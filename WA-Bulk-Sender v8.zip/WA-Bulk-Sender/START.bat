@echo off
title WA Bulk Sender
cd /d "%~dp0"

echo ============================================
echo   WA Bulk Sender - Starting...
echo ============================================
echo.

REM Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not installed.
    echo Download from: https://nodejs.org/en/download
    pause
    exit /b 1
)

REM Get current Node version (e.g. v24.16.0)
for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo Using Node %NODE_VER%

REM Read saved node version (if any)
set SAVED_VER=
if exist ".node-version" set /p SAVED_VER=<.node-version

REM If node_modules missing OR node version changed -> reinstall
set NEED_INSTALL=0
if not exist "node_modules" set NEED_INSTALL=1
if not "%NODE_VER%"=="%SAVED_VER%" set NEED_INSTALL=1

if "%NEED_INSTALL%"=="1" (
    echo.
    if exist "node_modules" (
        echo Node version changed [old=%SAVED_VER% new=%NODE_VER%] - rebuilding dependencies...
        rmdir /s /q node_modules 2>nul
        if exist "package-lock.json" del /q package-lock.json 2>nul
    ) else (
        echo First time setup - installing dependencies...
    )
    echo This may take 2-3 minutes...
    echo.
    call npm install --no-fund --no-audit
    if errorlevel 1 (
        echo.
        echo ERROR: npm install failed. Check internet connection.
        pause
        exit /b 1
    )
    REM Save current Node version
    echo %NODE_VER%> .node-version
)

echo.
echo Starting server...
echo Open in browser: http://localhost:3000
echo.
echo (Keep this window open. Press Ctrl+C to stop.)
echo.

REM Open browser after 4 seconds
start "" cmd /c "timeout /t 4 /nobreak >nul & start http://localhost:3000"

call npm start
pause
