// app.js — frontend logic
const $ = (s) => document.querySelector(s);

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

// ---- Connection ----
async function refreshStatus() {
  try {
    const s = await api('/api/wa/status');
    const pill = $('#conn-pill');
    if (s.state === 'connected') {
      pill.textContent = '🟢 Connected' + (s.user?.id ? ' (' + s.user.id.split(':')[0] + ')' : '');
      pill.className = 'pill green';
      $('#conn-msg').textContent = 'WhatsApp linked successfully ✅';
      $('#qr-box').style.display = 'none';
      $('#btn-logout').style.display = 'inline-block';
    } else if (s.state === 'qr' && s.qr) {
      pill.textContent = '🟡 Waiting for QR scan';
      pill.className = 'pill amber';
      $('#conn-msg').textContent = '';
      $('#qr-img').src = s.qr;
      $('#qr-box').style.display = 'block';
      $('#btn-logout').style.display = 'none';
    } else if (s.state === 'connecting') {
      pill.textContent = '🟡 Connecting…';
      pill.className = 'pill amber';
      $('#conn-msg').textContent = 'Connecting to WhatsApp…';
      $('#qr-box').style.display = 'none';
    } else {
      pill.textContent = '🔴 Disconnected';
      pill.className = 'pill red';
      $('#conn-msg').textContent = 'Not connected.';
      $('#qr-box').style.display = 'none';
      $('#btn-logout').style.display = 'none';
      // auto-trigger connect
      api('/api/wa/connect', { method: 'POST' }).catch(() => {});
    }
  } catch (e) {
    console.error(e);
  }
}

$('#btn-logout').onclick = async () => {
  if (!confirm('Logout? You will need to scan QR again.')) return;
  await api('/api/wa/logout', { method: 'POST' });
  await refreshStatus();
};

// ---- Sync groups + select / save batch ----
let allGroups = [];
const selectedJids = new Set();

$('#btn-sync').onclick = async () => {
  $('#sync-count').textContent = 'Syncing…';
  try {
    const r = await api('/api/groups/sync', { method: 'POST' });
    $('#sync-count').textContent = `✅ ${r.count} groups synced`;
    await loadGroups();
  } catch (e) {
    $('#sync-count').textContent = '❌ ' + e.message;
  }
};

$('#btn-export-groups').onclick = () => {
  // Direct download via anchor — server streams CSV with filename header.
  window.location.href = '/api/groups/export.csv';
};

async function loadGroups() {
  try {
    allGroups = await api('/api/groups');
    renderGroupsTable();
    $('#sync-count').textContent = $('#sync-count').textContent ||
      (allGroups.length ? `${allGroups.length} groups in cache` : '');
  } catch (e) { console.error(e); }
}

function renderGroupsTable() {
  const wrap = $('#groups-table-wrap');
  const toolbar = $('#groups-toolbar');
  const saveRow = $('#save-batch-row');
  if (!allGroups.length) {
    wrap.style.display = 'none';
    toolbar.style.display = 'none';
    saveRow.style.display = 'none';
    return;
  }
  wrap.style.display = '';
  toolbar.style.display = '';
  saveRow.style.display = '';

  const filter = ($('#group-filter').value || '').toLowerCase().trim();
  const tbody = $('#groups-table tbody');
  tbody.innerHTML = '';
  let shown = 0;
  for (const g of allGroups) {
    if (filter && !String(g.name || '').toLowerCase().includes(filter)) continue;
    shown++;
    const tr = document.createElement('tr');
    const checked = selectedJids.has(g.jid) ? 'checked' : '';
    tr.innerHTML = `
      <td><input type="checkbox" data-jid="${escapeHtml(g.jid)}" ${checked} /></td>
      <td>${escapeHtml(g.name || '(unnamed)')}</td>
      <td>${g.is_admin_only ? '<span class="pill amber">admin</span>' : ''}</td>`;
    tbody.appendChild(tr);
  }
  tbody.querySelectorAll('input[type=checkbox]').forEach(cb => {
    cb.addEventListener('change', () => {
      const jid = cb.dataset.jid;
      if (cb.checked) selectedJids.add(jid); else selectedJids.delete(jid);
      updateSelectedCount();
    });
  });
  updateSelectedCount(shown);
}

function updateSelectedCount(shown) {
  $('#group-selected-count').textContent =
    `${selectedJids.size} selected` + (shown != null ? ` · ${shown} shown` : '');
}

$('#group-filter').oninput = renderGroupsTable;
$('#chk-head').onchange = (e) => {
  // Toggle visible rows only
  $('#groups-table tbody').querySelectorAll('input[type=checkbox]').forEach(cb => {
    cb.checked = e.target.checked;
    const jid = cb.dataset.jid;
    if (cb.checked) selectedJids.add(jid); else selectedJids.delete(jid);
  });
  updateSelectedCount();
};
$('#btn-select-all').onclick = () => {
  $('#groups-table tbody').querySelectorAll('input[type=checkbox]').forEach(cb => {
    cb.checked = true; selectedJids.add(cb.dataset.jid);
  });
  updateSelectedCount();
};
$('#btn-select-none').onclick = () => {
  selectedJids.clear();
  renderGroupsTable();
};

$('#btn-save-batch').onclick = async () => {
  const name = $('#batch-name').value.trim();
  if (!name) { $('#save-batch-result').textContent = '⚠️ Give the batch a name'; return; }
  if (!selectedJids.size) { $('#save-batch-result').textContent = '⚠️ Pick at least one group'; return; }
  $('#save-batch-result').textContent = 'Saving…';
  try {
    const r = await api('/api/batches', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, group_jids: Array.from(selectedJids) }),
    });
    $('#save-batch-result').textContent = `✅ Saved batch #${r.batch_id} (${r.count} groups)`;
    $('#batch-name').value = '';
    loadBatches();
  } catch (e) {
    $('#save-batch-result').textContent = '❌ ' + e.message;
  }
};

// ---- Batches ----
let allBatches = [];
async function loadBatches() {
  try {
    allBatches = await api('/api/batches');
    renderBatches();
    refreshBatchPicker();
  } catch (e) { console.error(e); }
}

function renderBatches() {
  const box = $('#batches-list');
  if (!allBatches.length) {
    box.innerHTML = '<p class="muted">No batches yet. Pick some groups above and save one.</p>';
    return;
  }
  box.innerHTML = allBatches.map(b => `
    <div class="batch-item">
      <div><b>#${b.id} — ${escapeHtml(b.name)}</b> <span class="muted">· ${b.group_count} groups · ${new Date(b.created_at).toLocaleString()}</span></div>
      <div style="margin-top:6px">
        <button class="secondary" onclick="viewBatch(${b.id})">👁 View groups</button>
        <a class="button-link" href="/api/batches/${b.id}/export.csv">⬇ Download CSV</a>
        <button class="danger" onclick="deleteBatch(${b.id})">🗑 Delete</button>
      </div>
      <div id="batch-${b.id}-detail"></div>
    </div>`).join('');
}

function refreshBatchPicker() {
  const sel = $('#batch-picker');
  if (!allBatches.length) {
    sel.innerHTML = '<option value="">— No saved batches yet —</option>';
  } else {
    sel.innerHTML = allBatches.map(b =>
      `<option value="${b.id}">${escapeHtml(b.name)} (${b.group_count} groups)</option>`
    ).join('');
  }
}

window.viewBatch = async (id) => {
  const box = document.getElementById(`batch-${id}-detail`);
  if (!box) return;
  if (box.dataset.open === '1') { box.innerHTML = ''; box.dataset.open = '0'; return; }
  try {
    const j = await api('/api/batches/' + id);
    box.innerHTML = '<ul class="batch-groups">' +
      j.groups.map(g => `<li>${escapeHtml(g.group_name)}</li>`).join('') + '</ul>';
    box.dataset.open = '1';
  } catch (e) { box.textContent = '❌ ' + e.message; }
};

window.deleteBatch = async (id) => {
  if (!confirm('Delete this batch? Existing campaigns are unaffected.')) return;
  try { await api('/api/batches/' + id, { method: 'DELETE' }); loadBatches(); }
  catch (e) { alert(e.message); }
};

// ---- Campaign source toggle ----
$('#source-select').onchange = () => {
  const v = $('#source-select').value;
  $('#batch-picker-label').style.display = (v === 'batch') ? '' : 'none';
  $('#csv-input-label').style.display = (v === 'csv') ? '' : 'none';
};

// ---- Create campaign ----
$('#campaign-form').onsubmit = async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const source = $('#source-select').value;
  if (source === 'batch') {
    fd.delete('csv');
    if (!fd.get('batch_id')) {
      $('#create-result').innerHTML = '❌ Pick a saved batch (or switch to CSV upload)';
      return;
    }
  } else {
    fd.delete('batch_id');
    const csv = fd.get('csv');
    if (!csv || (csv && csv.size === 0)) {
      $('#create-result').innerHTML = '❌ Choose a CSV file';
      return;
    }
  }
  $('#create-result').innerHTML = 'Creating…';
  try {
    const r = await fetch('/api/campaigns', { method: 'POST', body: fd });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Failed');
    let html = `<p>✅ Campaign #${j.campaign_id} created with <b>${j.matched}</b> groups matched.</p>`;
    if (j.unmatched?.length) {
      html += `<details><summary>${j.unmatched.length} unmatched (click)</summary><ul>` +
        j.unmatched.map(u => `<li>${u}</li>`).join('') + `</ul></details>`;
    }
    $('#create-result').innerHTML = html;
    e.target.reset();
    loadCampaigns();
  } catch (err) {
    $('#create-result').innerHTML = '❌ ' + err.message;
  }
};

// ---- Campaigns list ----
async function loadCampaigns() {
  try {
    const camps = await api('/api/campaigns');
    const box = $('#campaigns-list');
    if (!camps.length) { box.innerHTML = '<p class="muted">No campaigns yet.</p>'; return; }
    box.innerHTML = camps.map(c => {
      const pct = c.total ? Math.round((c.sent / c.total) * 100) : 0;
      const statusPill = {
        running: '🟢 running', paused: '🟡 paused', done: '✅ done',
        stopped: '🔴 stopped', created: '⚪ created'
      }[c.status] || c.status;
      return `
      <div class="campaign-item">
        <div style="display:flex;justify-content:space-between">
          <b>#${c.id} — ${escapeHtml(c.name)}</b>
          <span class="pill">${statusPill}</span>
        </div>
        <div class="stats">
          <span>📊 ${c.sent}/${c.total} sent (${pct}%)</span>
          <span>⏳ ${c.pending} pending</span>
          <span>❌ ${c.failed} failed</span>
          <span>⏭ ${c.skipped} skipped</span>
        </div>
        <div class="bar"><div style="width:${pct}%"></div></div>
        <div>
          <button onclick="startCamp(${c.id})">▶ Start/Resume</button>
          <button class="secondary" onclick="pauseCamp(${c.id})">⏸ Pause</button>
          <button class="danger" onclick="stopCamp(${c.id})">⏹ Stop</button>
          <button class="secondary" onclick="retryCamp(${c.id})" title="Re-queue skipped + failed targets">🔁 Retry skipped/failed</button>
          <button class="danger" onclick="deleteCamp(${c.id})">🗑 Delete</button>
        </div>
      </div>`;
    }).join('');
  } catch (e) {
    console.error(e);
  }
}

window.startCamp = async (id) => { await api(`/api/campaigns/${id}/start`, { method: 'POST' }).catch(e => alert(e.message)); loadCampaigns(); };
window.pauseCamp = async (id) => { await api(`/api/campaigns/${id}/pause`, { method: 'POST' }).catch(e => alert(e.message)); loadCampaigns(); };
window.stopCamp = async (id) => { if (!confirm('Stop?')) return; await api(`/api/campaigns/${id}/stop`, { method: 'POST' }).catch(e => alert(e.message)); loadCampaigns(); };
window.deleteCamp = async (id) => { if (!confirm('Delete campaign + all its records?')) return; await api(`/api/campaigns/${id}`, { method: 'DELETE' }).catch(e => alert(e.message)); loadCampaigns(); };
window.retryCamp = async (id) => {
  if (!confirm('Re-queue all skipped + failed groups for this campaign? You\'ll need to hit Start again after.')) return;
  try {
    const r = await api(`/api/campaigns/${id}/retry`, { method: 'POST' });
    alert(`Re-queued ${r.requeued} target(s). Click ▶ Start to retry.`);
    loadCampaigns();
  } catch (e) { alert(e.message); }
};

$('#btn-refresh-camps').onclick = loadCampaigns;

// ---- Logs ----
async function loadLogs() {
  try {
    const logs = await api('/api/logs');
    $('#logs').textContent = logs.reverse().map(l =>
      `[${new Date(l.ts).toLocaleTimeString()}] [${l.level}] ${l.msg}`
    ).join('\n');
  } catch (e) {}
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

// ---- Boot ----
refreshStatus();
loadCampaigns();
loadLogs();
loadGroups();
loadBatches();
setInterval(refreshStatus, 3000);
setInterval(loadCampaigns, 5000);
setInterval(loadLogs, 4000);
