// db.js — pure-JS JSON file store with SQL-like API shim
// Replaces better-sqlite3 to avoid native compilation issues
const path = require('path');
const fs = require('fs');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_FILE = path.join(DATA_DIR, 'store.json');

// In-memory store, persisted to disk
const store = loadStore();

function loadStore() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      return {
        groups: parsed.groups || [],
        campaigns: parsed.campaigns || [],
        campaign_targets: parsed.campaign_targets || [],
        batches: parsed.batches || [],
        batch_groups: parsed.batch_groups || [],
        logs: parsed.logs || [],
        nextId: Object.assign({ campaigns: 1, campaign_targets: 1, batches: 1, batch_groups: 1, logs: 1 }, parsed.nextId || {}),
      };
    }
  } catch (e) {
    console.error('Failed to load store, starting fresh:', e.message);
  }
  return {
    groups: [],
    campaigns: [],
    campaign_targets: [],
    batches: [],
    batch_groups: [],
    logs: [],
    nextId: { campaigns: 1, campaign_targets: 1, batches: 1, batch_groups: 1, logs: 1 },
  };
}

let saveTimer = null;
function persist() {
  // Debounce writes (max 1 write per 500ms)
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(store, null, 2));
    } catch (e) {
      console.error('Persist failed:', e.message);
    }
  }, 500);
}

function persistNow() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  try { fs.writeFileSync(DB_FILE, JSON.stringify(store, null, 2)); } catch (e) {}
}

// ---------- SQL-like API shim ----------
// We implement only the specific queries used by the app.
// All other code can call db.prepare(sql).run(...).get(...).all(...) etc.

function prepare(sql) {
  const norm = sql.replace(/\s+/g, ' ').trim();
  return {
    run: (...args) => execRun(norm, args),
    get: (...args) => execGet(norm, args),
    all: (...args) => execAll(norm, args),
  };
}

function execRun(sql, args) {
  // ---- groups ----
  if (sql.startsWith("INSERT INTO groups (jid, name, is_admin_only, i_am_member, last_synced)")) {
    const [jid, name, isAdminOnly, iAmMember, lastSynced] = args;
    const existing = store.groups.find(g => g.jid === jid);
    if (existing) {
      existing.name = name;
      existing.is_admin_only = isAdminOnly;
      existing.i_am_member = 1;
      existing.last_synced = lastSynced;
    } else {
      store.groups.push({
        jid, name, is_admin_only: isAdminOnly, i_am_member: iAmMember, last_synced: lastSynced
      });
    }
    persist();
    return { changes: 1 };
  }

  // ---- campaigns ----
  if (sql.startsWith("INSERT INTO campaigns")) {
    // Two shapes are accepted to stay backward-compatible with older callers:
    //   9 args (no media_type) : name, message, image_path, delay_min, ...
    //  10 args (with media_type): name, message, image_path, media_type, delay_min, ...
    let name, message, image_path, media_type, delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour, created_at;
    if (args.length === 10) {
      [name, message, image_path, media_type, delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour, created_at] = args;
    } else {
      [name, message, image_path, delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour, created_at] = args;
      media_type = image_path ? 'image' : null;
    }
    const id = store.nextId.campaigns++;
    store.campaigns.push({
      id, name, message, image_path, media_type,
      status: 'created',
      delay_min, delay_max, per_day_cap, day_start_hour, day_end_hour,
      created_at, started_at: null, finished_at: null
    });
    persist();
    return { changes: 1, lastInsertRowid: id };
  }

  if (sql.startsWith("UPDATE campaigns SET status='running'")) {
    const [now, id] = args;
    const c = store.campaigns.find(c => c.id == id);
    if (c) { c.status = 'running'; if (!c.started_at) c.started_at = now; }
    persist();
    return { changes: c ? 1 : 0 };
  }
  if (sql.startsWith("UPDATE campaigns SET status='stopped'")) {
    // Two shapes:
    //   UPDATE campaigns SET status='stopped' WHERE id=?              -> [id]
    //   UPDATE campaigns SET status='stopped', finished_at=? WHERE id=? -> [finished_at, id]
    let finished_at, id;
    if (args.length === 1) { id = args[0]; }
    else { [finished_at, id] = args; }
    const c = store.campaigns.find(c => c.id == id);
    if (c) {
      c.status = 'stopped';
      if (finished_at != null) c.finished_at = finished_at;
    }
    persist();
    return { changes: c ? 1 : 0 };
  }
  if (sql.startsWith("UPDATE campaigns SET status='paused'")) {
    const [id] = args;
    const c = store.campaigns.find(c => c.id == id);
    if (c) c.status = 'paused';
    persist();
    return { changes: c ? 1 : 0 };
  }
  if (sql.startsWith("UPDATE campaigns SET status='done'")) {
    const [now, id] = args;
    const c = store.campaigns.find(c => c.id == id);
    if (c) { c.status = 'done'; c.finished_at = now; }
    persist();
    return { changes: c ? 1 : 0 };
  }

  if (sql.startsWith("DELETE FROM campaigns WHERE id=")) {
    const [id] = args;
    const before = store.campaigns.length;
    store.campaigns = store.campaigns.filter(c => c.id != id);
    persist();
    return { changes: before - store.campaigns.length };
  }

  // ---- campaign_targets ----
  if (sql.startsWith("INSERT INTO campaign_targets")) {
    const [campaign_id, group_jid, group_name] = args;
    const id = store.nextId.campaign_targets++;
    store.campaign_targets.push({
      id, campaign_id, group_jid, group_name,
      status: 'pending', error: null, sent_at: null
    });
    persist();
    return { changes: 1, lastInsertRowid: id };
  }

  if (sql.startsWith("UPDATE campaign_targets SET status='sent'")) {
    const [sent_at, id] = args;
    const t = store.campaign_targets.find(t => t.id == id);
    if (t) { t.status = 'sent'; t.sent_at = sent_at; }
    persist();
    return { changes: t ? 1 : 0 };
  }
  if (sql.startsWith("UPDATE campaign_targets SET status='failed'")) {
    const [error, sent_at, id] = args;
    const t = store.campaign_targets.find(t => t.id == id);
    if (t) { t.status = 'failed'; t.error = error; t.sent_at = sent_at; }
    persist();
    return { changes: t ? 1 : 0 };
  }
  if (sql.startsWith("UPDATE campaign_targets SET status='skipped'")) {
    // Handle two shapes:
    //   1) ... error='admin_only', sent_at=? WHERE id=?  -> args: [sent_at, id]
    //   2) ... error=?, sent_at=? WHERE id=?            -> args: [error, sent_at, id]
    let error, sent_at, id;
    if (args.length === 2) {
      const m = sql.match(/error='([^']*)'/);
      error = m ? m[1] : null;
      [sent_at, id] = args;
    } else {
      [error, sent_at, id] = args;
    }
    const t = store.campaign_targets.find(t => t.id == id);
    if (t) { t.status = 'skipped'; t.error = error; t.sent_at = sent_at; }
    persist();
    return { changes: t ? 1 : 0 };
  }

  if (sql.startsWith("UPDATE campaign_targets SET status='pending', error=NULL, sent_at=NULL WHERE campaign_id=")) {
    const [id] = args;
    let changes = 0;
    for (const t of store.campaign_targets) {
      if (t.campaign_id == id && (t.status === 'skipped' || t.status === 'failed')) {
        t.status = 'pending';
        t.error = null;
        t.sent_at = null;
        changes++;
      }
    }
    persist();
    return { changes };
  }
  if (sql.startsWith("UPDATE campaigns SET status='created', finished_at=NULL WHERE id=")) {
    const [id] = args;
    const c = store.campaigns.find(c => c.id == id);
    if (c) { c.status = 'created'; c.finished_at = null; }
    persist();
    return { changes: c ? 1 : 0 };
  }
  if (sql.startsWith("DELETE FROM campaign_targets WHERE campaign_id=")) {
    const [id] = args;
    const before = store.campaign_targets.length;
    store.campaign_targets = store.campaign_targets.filter(t => t.campaign_id != id);
    persist();
    return { changes: before - store.campaign_targets.length };
  }

  // ---- batches ----
  if (sql.startsWith("INSERT INTO batches")) {
    const [name, created_at] = args;
    const id = store.nextId.batches++;
    store.batches.push({ id, name, created_at });
    persist();
    return { changes: 1, lastInsertRowid: id };
  }
  if (sql.startsWith("UPDATE batches SET name=")) {
    const [name, id] = args;
    const b = store.batches.find(b => b.id == id);
    if (b) b.name = name;
    persist();
    return { changes: b ? 1 : 0 };
  }
  if (sql.startsWith("DELETE FROM batches WHERE id=")) {
    const [id] = args;
    const before = store.batches.length;
    store.batches = store.batches.filter(b => b.id != id);
    store.batch_groups = store.batch_groups.filter(bg => bg.batch_id != id);
    persist();
    return { changes: before - store.batches.length };
  }

  // ---- batch_groups ----
  if (sql.startsWith("INSERT INTO batch_groups")) {
    const [batch_id, group_jid, group_name] = args;
    const id = store.nextId.batch_groups++;
    store.batch_groups.push({ id, batch_id, group_jid, group_name });
    persist();
    return { changes: 1, lastInsertRowid: id };
  }
  if (sql.startsWith("DELETE FROM batch_groups WHERE batch_id=")) {
    const [id] = args;
    const before = store.batch_groups.length;
    store.batch_groups = store.batch_groups.filter(bg => bg.batch_id != id);
    persist();
    return { changes: before - store.batch_groups.length };
  }

  // ---- logs ----
  if (sql.startsWith("INSERT INTO logs")) {
    const [ts, level, msg] = args;
    const id = store.nextId.logs++;
    store.logs.push({ id, ts, level, msg });
    // Cap logs at 500 entries
    if (store.logs.length > 500) store.logs = store.logs.slice(-500);
    persist();
    return { changes: 1, lastInsertRowid: id };
  }

  throw new Error('Unknown SQL run: ' + sql.slice(0, 80));
}

function execGet(sql, args) {
  if (sql.startsWith("SELECT * FROM campaigns WHERE id=")) {
    return store.campaigns.find(c => c.id == args[0]) || null;
  }
  if (sql.startsWith("SELECT * FROM batches WHERE id=")) {
    return store.batches.find(b => b.id == args[0]) || null;
  }
  if (sql.startsWith("SELECT * FROM groups WHERE jid=")) {
    return store.groups.find(g => g.jid === args[0]) || null;
  }
  if (sql.startsWith("SELECT * FROM campaign_targets WHERE campaign_id=") && sql.includes("status='pending'")) {
    return store.campaign_targets
      .filter(t => t.campaign_id == args[0] && t.status === 'pending')
      .sort((a, b) => a.id - b.id)[0] || null;
  }
  if (sql.startsWith("SELECT COUNT(*) as c FROM campaign_targets WHERE campaign_id=") && sql.includes("status='sent' AND sent_at >=")) {
    const [cid, since] = args;
    const c = store.campaign_targets.filter(t => t.campaign_id == cid && t.status === 'sent' && (t.sent_at || 0) >= since).length;
    return { c };
  }

  throw new Error('Unknown SQL get: ' + sql.slice(0, 80));
}

function execAll(sql, args) {
  if (sql.startsWith("SELECT * FROM groups ORDER BY name")) {
    return [...store.groups].sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  }
  if (sql.startsWith("SELECT * FROM groups")) {
    return [...store.groups];
  }
  if (sql.startsWith("SELECT c.*,")) {
    // Campaigns list with aggregates
    return store.campaigns
      .slice()
      .sort((a, b) => b.id - a.id)
      .map(c => {
        const targets = store.campaign_targets.filter(t => t.campaign_id == c.id);
        return {
          ...c,
          total: targets.length,
          sent: targets.filter(t => t.status === 'sent').length,
          failed: targets.filter(t => t.status === 'failed').length,
          skipped: targets.filter(t => t.status === 'skipped').length,
          pending: targets.filter(t => t.status === 'pending').length,
        };
      });
  }
  if (sql.startsWith("SELECT * FROM campaign_targets WHERE campaign_id=") && sql.includes("ORDER BY id")) {
    return store.campaign_targets
      .filter(t => t.campaign_id == args[0])
      .sort((a, b) => a.id - b.id);
  }
  if (sql.startsWith("SELECT * FROM batches ORDER BY id DESC")) {
    return store.batches.slice().sort((a, b) => b.id - a.id).map(b => ({
      ...b,
      group_count: store.batch_groups.filter(bg => bg.batch_id == b.id).length,
    }));
  }
  if (sql.startsWith("SELECT * FROM batch_groups WHERE batch_id=")) {
    return store.batch_groups.filter(bg => bg.batch_id == args[0]).sort((a, b) => a.id - b.id);
  }
  if (sql.startsWith("SELECT * FROM logs ORDER BY id DESC LIMIT")) {
    return [...store.logs].sort((a, b) => b.id - a.id).slice(0, 200);
  }

  throw new Error('Unknown SQL all: ' + sql.slice(0, 80));
}

// Transaction shim (just runs the function — no real transactions needed for JSON)
function transaction(fn) {
  return (...args) => {
    const result = fn(...args);
    persistNow();
    return result;
  };
}

// Pragma shim (no-op)
function pragma() {}

const db = { prepare, transaction, pragma };

function log(level, msg) {
  try {
    db.prepare('INSERT INTO logs (ts, level, msg) VALUES (?,?,?)').run(Date.now(), level, msg);
  } catch (e) {}
  const stamp = new Date().toISOString();
  console.log(`[${stamp}] [${level}] ${msg}`);
}

// Persist on exit
process.on('exit', persistNow);
process.on('SIGINT', () => { persistNow(); process.exit(0); });
process.on('SIGTERM', () => { persistNow(); process.exit(0); });

module.exports = { db, log };
